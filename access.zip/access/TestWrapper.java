package com.access;

public class TestWrapper {
	enum Color {
		RED,GREEN,YELLOW,BLUE;
	}
	public static void main(String[] args) {
		Color c1 = Color.GREEN;
		System.out.println(c1);
	}

}
