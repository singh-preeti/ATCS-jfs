package com.access1;
class  Inner_class_Demo
{
	private int age = 30;
	
	class Inner
	{
		void showAge()
		{
			System.out.println("age is "+age);
		}
	}
	public static void main(String[] args) {
		Inner_class_Demo obj = new Inner_class_Demo();
		Inner_class_Demo.Inner in = obj.new Inner();
		in.showAge();
	}
}
//public class Inner_class_Demo {
//
//}
