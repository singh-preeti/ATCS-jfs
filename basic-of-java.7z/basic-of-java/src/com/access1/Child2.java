package com.access1;
import com.access.*;

 class Child2 {
 public static void main(String[] args) {
	 PubPrivateDemo p3 = new PubPrivateDemo();
	p3.add(20,10);
}
}
