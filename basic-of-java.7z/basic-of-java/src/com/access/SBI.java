package com.access;
// Single inheritance
// Parent class 
class RBI 
{
	public void setOfRules()
	{
		System.out.println("rules will be followed by all the banks!");
	}
}
// final -> can not be inherited -> can not be extended by other class
 class Bank extends RBI
{
     int rateOfInterest()
    {
    	System.out.println("Current rate of interest is 6.5%");
		return 0;
    	
    }
}
//Child Class
class ICICI extends Bank
{
	void statementWithdrwal()
	{
		System.out.println("We mail account statement instantly");
	}
}
public class SBI extends Bank
{
//	@Override
//	 private int rateOfInterest()
//    {
//    	System.out.println("Current rate of interest is 6.5%");
//		return 0;
//    	
//    }
	
	void loanFacility()
	{
		System.out.println("We provide loan based on salary amount");
	}
	void creditCardFacility()
	{
		System.out.println("We provide card to our customer!");
	}
	public static void main(String[] args) {
		   SBI bank = new SBI();
		   Bank b = new Bank();
		   bank.rateOfInterest();
		   bank.creditCardFacility();
		   bank.loanFacility();
		   bank.setOfRules();
		  
	}
}

