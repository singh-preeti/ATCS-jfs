package com.access;
class Parent1
{
  void display()
  {
	  System.out.println("Display");
  }
}
interface  Parent2
{
	 void display();
}
 class MultipleInheritanceDemo  extends Parent1 implements  Parent2{
	public static void main(String[] args) {
		MultipleInheritanceDemo obj =new MultipleInheritanceDemo();
		obj.display();
		//obj.show();
		obj.display();
	}
	@Override
	public
	
	void display()
	  {
		  System.out.println("Displaying...");
	  }

}
