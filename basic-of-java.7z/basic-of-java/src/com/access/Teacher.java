package com.access;
//poly= many morphism= forms
// vehicle -> many forms -> 2 wheelers,3 wheelers,4 wheelers
class Person
{
   String name;
   
   void speak()
   {
	   System.out.println("I am"+name+ "and I can speak about java");
   }
   void walk()
   {
	   System.out.println("I can walk fast");
   }
}

public class Teacher extends Person   {
	String course;
	
	void traine()
	{
		System.out.println("I can traine" + course);
	}
	
	public static void main(String[] args) {
		Teacher t1 = new Teacher();
		t1.name = "Rohit";
		t1.course = "IT courses";
		
		t1.speak();
		t1.walk();
		t1.traine();
		
		Person p1 = t1;
		p1.speak();
		p1.walk();
		//p1.traine();
	}

}
