package com.access;
class DemoEncapsule
{
	 private String name;
	 private String address;
	 
//	  public DemoEncapsule(String name, String address) {
//		super();
//		this.name = name;
//		this.address = address;
//	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		System.out.println("Setting the name variable...");
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}	
}

public class EncapsuleDemo  {
	 
	
	public static void main(String[] args) {
		DemoEncapsule obj = new DemoEncapsule();
		obj.setName("Preeti");
		obj.getName();
	} 
	 

}
