package com.access;
// reuse 
class Parent
{
	  void display()
	{
		System.out.println("Displaying parent class!");
	}
	void print()
	{
		System.out.println("Parent print method!");
	}
}
class Child1 extends Parent
{
	@Override
    void display()
  {
	  System.out.println("Displaying child class!");
  }
}
public class OverRideDemo {
  public static void main(String[] args) {
	  Child1 ch1 = new Child1();
	  ch1.display();
	  ch1.print();
	  
	  
	  
	  
	  
}
}
