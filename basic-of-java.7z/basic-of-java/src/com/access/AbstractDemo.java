package com.access;
//abstract -> method which can not implemented in the same class where it has declared
//abstract class Abs
//{
//   abstract void displayDetails();
//   int add() 
//   {System.out.println("addition");
//   return 0;}
//   
//}
// till java 7 non-abstract methods were not allowed in interface
interface Abs
{
	  void displayDetails();	
}
public class AbstractDemo implements Abs {

	@Override
	public void displayDetails() {
		System.out.println("Displaying..");
		
	}
	public static void main(String[] args) {
		AbstractDemo ab = new AbstractDemo();
		ab.displayDetails();
	}
	
	
}
