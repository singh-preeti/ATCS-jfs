package com.access;
@FunctionalInterface
class Bank2
{
	void withdraw() {};
	 //default void loanEnquiry() {};
	 
}
interface Bank1
{
    void deposite();	
}

public class InterfaceDemo extends Bank2 implements Bank1
{

	@Override
	public void deposite() {
		System.out.println("Deposite completed");
		
	}

	@Override
	public void withdraw() {
		System.out.println("withdrawal completed");
		
	}
	public static void main(String[] args) {
		InterfaceDemo i1 = new InterfaceDemo();
		i1.deposite();
		i1.withdraw();
		//i1.creditLimit();
	}
	
}
