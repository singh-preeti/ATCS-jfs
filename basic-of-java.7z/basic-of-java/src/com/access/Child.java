package com.access;

public class Child {
public static void main(String[] args) {
	PubPrivateDemo p2= new PubPrivateDemo();
	p2.add(20, 10);
}
}
