package com.access;
class Test{

	public int add()
	{
		int x=10;
		int y=10;
		int c= x+y;
		System.out.println(c);
		return c;
	}
	public int add(int a,int b)
	{
		
		int c=a+b;
		System.out.println(c);
		return c;
	}
	
}

public class PolyDemo {
	
	public int add(int a,int b)
	{
		
		int c=a+b;
		System.out.println(c);
		return c;
	}

}
