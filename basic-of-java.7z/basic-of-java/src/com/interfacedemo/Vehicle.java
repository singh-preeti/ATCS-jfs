package com.interfacedemo;

public interface Vehicle {
	
	public  void startEngine();
	public  void Accelerate();
	public  void brake();
	public  void honk();
	

}